package br.com.quimica;

public class elementosObj {
	
	private String nome;
	private String DristEletronica;
	private String familia;
	private String formula;
	
	public elementosObj (String nome, String DristEletronica, String familia, String formula) 
	{
		this.nome = nome;
		this.DristEletronica = DristEletronica;
		this.familia = familia;
		this.formula = formula;
	}
	
	public elementosObj() {
		this("","","","");
	}
	
	public String getDristEletronica() {
		return this.DristEletronica;
	}
	
	public String getFamilia() {
		return this.familia;
	}
	
	public String getFormula() {
		return this.formula;
	}
	
	public void setDristEletronica(String DristEletro) {
		this.DristEletronica = DristEletro;
	}
	
	public void setFamilia (String familia) {
		this.familia = familia;
	}
	
	public void setFormula(String formula) {
		this.formula = formula;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String toString() {
		String retorno = this.nome+", "+this.DristEletronica+", "+ this.familia+", "+ this.formula;
		return retorno;
	}

}
