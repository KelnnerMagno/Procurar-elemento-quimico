package br.com.quimica;

import java.util.Scanner;

public class mainPrograma {
	
	public static void main (String [] args) 
	{
		Scanner input = new Scanner(System.in);
		int count = 1;
		while(count != 0) {
			System.out.println("Digite 0 pra sair");
			System.out.println("Digite o numero do elemento q deseja!");
			count = Integer.parseInt(input.nextLine());
			if(count >0) {
				System.out.println(Cadastro.getNum(count));
			}
			else if(count < 0) {
				System.out.println("Por favor, digite um numero n�o negativo");
			}
			else {
				count=0;
			}
			
		}
		input.close();
	}

}
